package com.example.jjy19.stockmonitor.RoomDatabase;

public class StockApplication {
}
